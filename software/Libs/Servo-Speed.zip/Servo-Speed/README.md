# Servo Speed

Non blocking servo control for servos on STM32 using the Arduino platform.

## Installation

Standard Arduino library installation.

## Usage
Currently only supports STM32 specifically bluepill. Arduino support to be added later

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.


## License
[MIT](https://choosealicense.com/licenses/mit/)